"""
PyBridge - a free online bridge game.
"""

__version__ = '0.3.0'

__author__ = 'Michael Banks <michael@banksie.co.uk>'
__license__ = 'GNU General Public License, Version 2 or later'
__url__ = 'http://pybridge.sourceforge.net/'

